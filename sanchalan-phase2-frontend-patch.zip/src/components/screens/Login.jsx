import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';

export default function Login() {
  const { login, error } = useAuth();
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!employeeId.trim() || !password) return;
    setSubmitting(true);
    await login(employeeId.trim(), password);
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <form onSubmit={onSubmit} className="w-full max-w-sm bg-cream-50 border border-cream-300 rounded-card shadow-panel p-6">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xl leading-none">🚦</span>
          <div>
            <div className="font-display font-semibold text-[15px] text-ink-900">SANCHALAN</div>
            <div className="text-[10px] uppercase tracking-[0.14em] text-ink-500">संचालन · Block Planning</div>
          </div>
        </div>
        <p className="text-[11.5px] text-ink-500 mb-5">Sign in with your employee ID to continue.</p>

        <label className="block text-[11px] text-ink-500 mb-1" htmlFor="employeeId">Employee ID</label>
        <input
          id="employeeId"
          value={employeeId}
          onChange={(e) => setEmployeeId(e.target.value)}
          placeholder="e.g. SR-DEN-01"
          autoFocus
          autoComplete="username"
          className="w-full mb-3 bg-cream-100 border border-cream-300 rounded-md px-3 py-2 text-[13px] outline-none focus:border-cyan-500"
        />

        <label className="block text-[11px] text-ink-500 mb-1" htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          className="w-full mb-4 bg-cream-100 border border-cream-300 rounded-md px-3 py-2 text-[13px] outline-none focus:border-cyan-500"
        />

        {error && (
          <div className="text-[11.5px] mb-3 px-3 py-2 rounded-md" style={{ background: '#FBEEEA', color: '#8F3A28' }}>
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full text-[12.5px] font-medium text-white py-2.5 rounded-md disabled:opacity-60"
          style={{ background: '#0F7A73' }}
        >
          {submitting ? 'Signing in…' : 'Sign in'}
        </button>

        <p className="text-[10.5px] text-ink-500 mt-4 text-center">
          Access is scoped to your department by the server — Engineering, Traction and
          S&amp;T users see the same console with different permissions.
        </p>
      </form>
    </div>
  );
}
